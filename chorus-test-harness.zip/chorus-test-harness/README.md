# Chorus NLP Test Harness

A standalone harness for iterating on the five Chorus NLP prompts (cast extraction, auto-casting, pronunciation, special content detection, dialogue attribution) against real book content, before committing to the full Chorus implementation.

**What it does:** takes a chapter or full book (TXT or EPUB), runs the prompts against Claude via the Anthropic API, and prints a human-readable report with cost tracking. Raw JSON outputs are saved for diffing across prompt revisions.

**What it's for:** the highest-leverage dev loop you have. Tune prompts here until the outputs look right, then port the winning prompt files into `backend/nlp/prompts/` in the main project.

---

## Setup

```bash
# 1. Clone/extract this directory
cd chorus-test-harness

# 2. Create a virtualenv (recommended)
python3 -m venv .venv
source .venv/bin/activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Set your API key
cp .env.example .env
# Edit .env and paste your ANTHROPIC_API_KEY
```

Requires **Python 3.11+**.

---

## Quick Start

```bash
# Run all five passes on a chapter in a plain text file
python test_harness.py --text ./some_chapter.txt

# Run on the first chapter of an EPUB
python test_harness.py --book ./agot.epub --chapter 1

# List chapters in an EPUB (no API calls)
python test_harness.py --book ./agot.epub --list-chapters

# Dry-run: render the prompts to disk but don't call the API
python test_harness.py --text ./some_chapter.txt --dry-run
```

Each run creates a timestamped subdirectory under `./outputs/run_YYYYMMDD_HHMMSS/` containing:
- `input_chapter.txt` / `input_full_book.txt` — the inputs used
- `cast.json` — extracted cast
- `casting.json` — voice assignments
- `pronunciations.json` — phonetic overrides
- `special_content.json` — detected epigraphs/letters/etc.
- `segments.json` — attributed segments for the chapter

---

## Iterating on Prompts

This is the main workflow:

1. **Run the harness** against a real chapter. Inspect the terminal output.
2. **Edit a prompt file** in `./prompts/`.
3. **Re-run** the harness (specify `--passes` to run only what you changed).
4. **Diff** the new `outputs/run_XXX/<pass>.json` against the previous run.
5. Repeat until happy.

Example: tuning the attribution prompt specifically:

```bash
# First run — baseline
python test_harness.py --text ./agot_ch1.txt

# Edit ./prompts/attribute_chapter.md

# Re-run only attribution (reuse the cast from the previous run)
python test_harness.py --text ./agot_ch1.txt \
    --passes attribute_chapter \
    --cast ./outputs/run_20260416_103000/cast.json
```

---

## CLI Reference

```
python test_harness.py [input options] [pass options] [output options]
```

### Input

| Flag | Description |
|---|---|
| `--text FILE` | Plain text or markdown file, treated as one chapter |
| `--book FILE` | EPUB file |
| `--chapter N` | Chapter number (1-indexed), for `--book` |
| `--chapter-title STR` | Match chapter by title substring, for `--book` |

### Passes

| Flag | Description |
|---|---|
| `--passes LIST` | Comma-separated pass names, or `all` (default). Valid: `extract_cast`, `auto_cast_voices`, `pronounce_unusual`, `detect_special_content`, `attribute_chapter` |
| `--cast FILE` | Reuse an existing cast JSON (skip extract_cast) |

### Models

| Flag | Default | Description |
|---|---|---|
| `--opus-model` | `claude-opus-4-7` | Used for heavy passes (extract, auto-cast, attribute) |
| `--sonnet-model` | `claude-sonnet-4-6` | Used for lighter passes (pronounce, special content) |

### Output

| Flag | Default | Description |
|---|---|---|
| `--output-dir DIR` | `./outputs` | Root output directory |
| `--dry-run` | — | Render prompts to disk; make no API calls |
| `--list-chapters` | — | List chapters of an EPUB and exit |

### Metadata

| Flag | Description |
|---|---|
| `--title STR` | Override book title |
| `--author STR` | Override book author |
| `--genre STR` | Genre hint (used for pronunciation pass) |

### Safety

| Flag | Default | Description |
|---|---|---|
| `--budget-cap USD` | `10.00` | Abort if cumulative cost exceeds this during a run |

---

## How the Passes Depend on Each Other

```
     ┌──────────────┐
     │ extract_cast │  (full book → cast)
     └──────┬───────┘
            │
            ├────────────────────┬──────────────────┐
            ▼                    ▼                  ▼
    ┌──────────────┐    ┌────────────────┐   ┌─────────────────────┐
    │ auto_cast_   │    │ pronounce_     │   │ detect_special_     │
    │ voices       │    │ unusual        │   │ content             │
    └──────────────┘    └────────────────┘   └──────────┬──────────┘
                                                        │
                                                        ▼
                                              ┌──────────────────┐
                                              │ attribute_       │
                                              │ chapter          │
                                              └──────────────────┘
```

Auto-casting, pronunciation, special content, and attribution all depend on the cast list. Special content and attribution can run independently of each other, but attribution benefits from having special content already tagged.

If you're re-running only one pass, use `--cast previous_run/cast.json` to skip extraction.

---

## Voice Library

The harness ships with `sample_voice_library.json` containing 20 sample voices across three pools:

- **Narrator pool (3):** literary narrators for book narration
- **Main pool (12):** distinct voices for named characters
- **Background pool (5):** generic voices for minor/unnamed characters

These are *metadata only* — the `voicebox_profile_id` field is absent because the harness isn't wired to Voicebox. The goal here is to test the *matching logic* of the auto-casting prompt, not to actually synthesize speech.

To use your own voice library:

```bash
python test_harness.py --text ./ch1.txt --voice-library ./my_library.json
```

---

## Costs

Each full run on a 6,000-word chapter of AGoT costs roughly:

| Pass | Model | Approx Cost |
|---|---|---|
| extract_cast | Opus 4.7 | $0.20–$0.80 (depends on book length) |
| auto_cast_voices | Opus 4.7 | $0.05–$0.15 |
| pronounce_unusual | Sonnet 4.6 | $0.01–$0.04 |
| detect_special_content | Sonnet 4.6 | $0.02–$0.08 |
| attribute_chapter | Opus 4.7 | $0.30–$1.20 per chapter |

**Per-chapter iteration cost:** typically $0.40–$1.50 when running all passes. Re-running just `attribute_chapter` after a prompt tweak is usually under $1.00.

The harness enforces a `--budget-cap` (default $10) that aborts the run if exceeded.

---

## Dry-Run Mode

If you want to use Claude Code (via your subscription) to run the passes manually instead of paying per-API-call:

```bash
python test_harness.py --text ./ch1.txt --dry-run
```

This renders each prompt with all substitutions filled in, saving them to `outputs/run_.../prompts/NN_<pass>.rendered.md`. You can paste each file into Claude Code, capture the output, and continue manually.

For faster iteration during active prompt tuning, live API mode is usually worth the few dollars.

---

## Files

```
chorus-test-harness/
├── README.md                      ← you are here
├── requirements.txt               ← Python dependencies
├── .env.example                   ← API key template
├── .gitignore
├── test_harness.py                ← main CLI entry
├── harness/
│   ├── __init__.py
│   ├── client.py                  ← Anthropic API wrapper with cost tracking
│   ├── prompts.py                 ← Prompt file loader
│   ├── ingest.py                  ← TXT/EPUB loading
│   ├── passes.py                  ← The five pass functions
│   ├── display.py                 ← Rich terminal output
│   └── voice_library.py           ← Voice library loader
├── prompts/
│   ├── extract_cast.md            ← Pass 1 prompt
│   ├── auto_cast_voices.md        ← Pass 2 prompt
│   ├── pronounce_unusual.md       ← Pass 3 prompt
│   ├── detect_special_content.md  ← Pass 4 prompt
│   └── attribute_chapter.md       ← Pass 5 prompt
├── sample_voice_library.json      ← 20 sample voices for auto-casting
└── outputs/                       ← (gitignored) timestamped run dirs
```

---

## Porting Tuned Prompts Back to the Main Project

Once a prompt is producing output you're happy with:

1. Copy the file from `chorus-test-harness/prompts/<name>.md`
2. Paste into `chorus/backend/nlp/prompts/<name>.md` in the main project
3. Commit with a message like `prompt: tune attribute_chapter — improved letter detection`

This separation keeps prompt iteration fast (harness) and keeps the main project stable.

---

## Troubleshooting

**JSON parse errors** — The harness tries to repair common issues (trailing commas, markdown fences), but if a pass still returns unparseable output, check the console error which includes a truncated preview of the response. Usually this means the prompt needs a stronger "return ONLY JSON" instruction.

**Budget exceeded** — You set `--budget-cap` lower than the run needed. Increase it or run individual passes.

**Rate limits** — The client retries transient errors with exponential backoff (2s, 4s, 8s). If you're hitting them frequently, upgrade your API tier or reduce parallelism (this harness runs serially, so rate limits are rare).

**ModuleNotFoundError: ebooklib** — You haven't installed dependencies. Run `pip install -r requirements.txt`.

**Chapter extraction returns wrong content** — EPUB chapter detection is heuristic. Use `--list-chapters` to see what the harness sees, then use `--chapter N` with the correct number.

---

## License

Same license as the parent Chorus project (MIT).
