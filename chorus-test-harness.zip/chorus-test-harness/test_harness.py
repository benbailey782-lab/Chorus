#!/usr/bin/env python3
"""Chorus NLP Test Harness.

Runs the five Chorus NLP prompts (cast extraction, auto-casting, pronunciation,
special content, attribution) against a chapter or book and prints a readable
report. Raw JSON outputs are saved for diffing across prompt revisions.

Usage examples:

    # Run all passes on a plain text file
    python test_harness.py --text chapter1.txt

    # Run all passes on chapter 1 of an EPUB
    python test_harness.py --book agot.epub --chapter 1

    # Run only attribution, reusing a previously-extracted cast
    python test_harness.py --text chapter1.txt \\
        --passes attribute_chapter --cast outputs/run_.../cast.json

    # Dry-run: render prompts to disk but make no API calls
    python test_harness.py --text chapter1.txt --dry-run

    # List chapters in an EPUB (no API calls)
    python test_harness.py --book agot.epub --list-chapters
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass  # dotenv is optional

from harness.client import HarnessClient, CostTracker
from harness.display import (
    console,
    print_cast,
    print_casting,
    print_cost_summary,
    print_error,
    print_header,
    print_info,
    print_pronunciations,
    print_segments,
    print_special_content,
    print_success,
    print_warn,
)
from harness.ingest import extract_chapter, list_chapters
from harness.passes import (
    dry_render_all,
    run_attribute_chapter,
    run_auto_cast_voices,
    run_detect_special_content,
    run_extract_cast,
    run_pronounce_unusual,
)
from harness.voice_library import get_default_library_path, load_voice_library


ALL_PASSES = [
    "extract_cast",
    "auto_cast_voices",
    "pronounce_unusual",
    "detect_special_content",
    "attribute_chapter",
]


def parse_args():
    p = argparse.ArgumentParser(
        description="Chorus NLP Test Harness",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )

    # Input
    src = p.add_mutually_exclusive_group(required=True)
    src.add_argument("--text", type=Path, help="Plain text or markdown file (treated as one chapter)")
    src.add_argument("--book", type=Path, help="EPUB file")

    # Chapter selection (for --book)
    p.add_argument("--chapter", type=int, help="Chapter number (1-indexed)")
    p.add_argument("--chapter-title", help="Match chapter by title substring")

    # Passes
    p.add_argument(
        "--passes",
        default="all",
        help=f"Comma-separated passes or 'all'. Available: {','.join(ALL_PASSES)}",
    )

    # Models
    p.add_argument("--opus-model", default="claude-opus-4-7", help="Model for heavy passes")
    p.add_argument("--sonnet-model", default="claude-sonnet-4-6", help="Model for lighter passes")

    # Voice library
    p.add_argument("--voice-library", type=Path, help="Voice library JSON (default: sample)")

    # Output
    p.add_argument("--output-dir", type=Path, default=Path("./outputs"), help="Output root directory")

    # Reuse existing artifacts
    p.add_argument("--cast", type=Path, help="Pre-extracted cast JSON to use (skip extract_cast)")

    # Dry run / utilities
    p.add_argument("--dry-run", action="store_true", help="Render prompts but do not call the API")
    p.add_argument("--list-chapters", action="store_true", help="List EPUB chapters and exit")

    # Metadata overrides
    p.add_argument("--title", help="Book title override")
    p.add_argument("--author", help="Book author override")
    p.add_argument("--genre", default="fiction", help="Book genre hint for pronunciation pass")

    # Behavior
    p.add_argument("--budget-cap", type=float, default=10.0, help="Abort if total cost exceeds this (USD)")

    return p.parse_args()


def resolve_passes(arg: str) -> list[str]:
    if arg.lower() == "all":
        return list(ALL_PASSES)
    return [x.strip() for x in arg.split(",") if x.strip()]


def ensure_run_dir(root: Path) -> Path:
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = root / f"run_{timestamp}"
    run_dir.mkdir(parents=True, exist_ok=True)
    return run_dir


def save_json(data, path: Path, label: str) -> None:
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    print_info(f"  → saved {label} to {path}")


def detect_pov(cast: list[dict], chapter_title: str) -> str:
    """Return the canonical name of the POV character if the chapter title matches one."""
    if not chapter_title:
        return ""
    needle = chapter_title.strip().lower()
    for c in cast:
        name = (c.get("name") or "").lower()
        if name and (name == needle or name in needle):
            return c.get("name", "")
        for alias in c.get("aliases", []) or []:
            if alias.lower() == needle:
                return c.get("name", "")
    return ""


def check_budget(tracker: CostTracker, cap: float) -> None:
    if tracker.total_cost > cap:
        print_error(
            f"Budget cap of ${cap:.2f} exceeded (spent ${tracker.total_cost:.2f}). Aborting."
        )
        sys.exit(2)


def main() -> None:
    args = parse_args()

    # Utility: list chapters
    if args.list_chapters:
        if not args.book:
            print_error("--list-chapters requires --book")
            sys.exit(1)
        chapters = list_chapters(args.book)
        print_header(f"Chapters in {args.book.name}")
        for num, title, words in chapters:
            console.print(f"  [cyan]{num:3d}[/cyan]  [white]{title}[/white]  [dim]({words:,} words)[/dim]")
        return

    # Validate env (unless dry-run)
    if not args.dry_run and not os.getenv("ANTHROPIC_API_KEY"):
        print_error("ANTHROPIC_API_KEY not set. Set in .env or environment.")
        sys.exit(1)

    # Resolve passes
    passes = resolve_passes(args.passes)
    invalid = [p for p in passes if p not in ALL_PASSES]
    if invalid:
        print_error(f"Unknown passes: {invalid}. Valid: {ALL_PASSES}")
        sys.exit(1)

    # Output dir
    run_dir = ensure_run_dir(args.output_dir)
    console.print()
    print_info(f"Output directory: {run_dir}")

    # Load input
    print_header("Loading Input")
    book_path = args.book or args.text
    try:
        metadata, chapter_title, chapter_text, full_book_text = extract_chapter(
            book_path,
            chapter_number=args.chapter,
            chapter_title=args.chapter_title,
        )
    except Exception as e:
        print_error(f"Failed to load input: {e}")
        sys.exit(1)

    book_title = args.title or metadata.get("title", "Unknown")
    book_author = args.author or metadata.get("author", "Unknown")

    chapter_words = len(chapter_text.split())
    book_words = len(full_book_text.split())

    print_success(f"Loaded: {book_title} by {book_author}")
    print_info(f"  Chapter: {chapter_title}")
    print_info(f"  Chapter words: {chapter_words:,}")
    print_info(f"  Full book words: {book_words:,}")

    # Warn on very long books
    est_tokens = book_words * 4 // 3  # very rough
    if "extract_cast" in passes and est_tokens > 150_000:
        print_warn(f"Book is ~{est_tokens:,} tokens — may exceed model context. Consider chunking.")

    # Save raw inputs for reference
    (run_dir / "input_chapter.txt").write_text(chapter_text, encoding="utf-8")
    if full_book_text != chapter_text:
        (run_dir / "input_full_book.txt").write_text(full_book_text, encoding="utf-8")

    # Voice library
    vl_path = args.voice_library or get_default_library_path()
    if not vl_path.exists():
        print_error(f"Voice library not found: {vl_path}")
        sys.exit(1)
    voice_library = load_voice_library(vl_path)
    print_info(f"Voice library: {vl_path.name} ({len(voice_library)} voices)")

    # Load existing cast if provided
    cast: list[dict] | None = None
    if args.cast:
        try:
            cast = json.loads(args.cast.read_text(encoding="utf-8"))
            print_info(f"Loaded existing cast from {args.cast}: {len(cast)} characters")
        except Exception as e:
            print_error(f"Could not load --cast file: {e}")
            sys.exit(1)

    # Dry-run short circuit
    if args.dry_run:
        print_header("Dry Run — Rendering Prompts")
        written = dry_render_all(
            out_dir=run_dir / "prompts",
            book_text=full_book_text,
            chapter_text=chapter_text,
            chapter_number=args.chapter or 1,
            chapter_title=chapter_title,
            pov_character_name="",
            cast=cast,
            voice_library=voice_library,
            book_title=book_title,
            book_author=book_author,
            book_genre=args.genre,
        )
        for p in written:
            print_success(f"Rendered → {p}")
        print_info("No API calls made. Inspect files or paste into Claude Code.")
        return

    # Set up client
    tracker = CostTracker()
    client = HarnessClient(tracker=tracker)

    # ─── Pass 1: Extract cast ───
    if "extract_cast" in passes:
        print_header("Pass 1: Cast Extraction")
        if cast is not None:
            print_info("Cast already provided via --cast; skipping extract_cast.")
        else:
            print_info(f"Running on {book_words:,} words using {args.opus_model}...")
            try:
                cast = run_extract_cast(client, full_book_text, model=args.opus_model)
                print_success(f"Extracted {len(cast)} characters")
                save_json(cast, run_dir / "cast.json", "cast")
                print_cast(cast)
            except Exception as e:
                print_error(f"Cast extraction failed: {e}")
                sys.exit(1)
        check_budget(tracker, args.budget_cap)

    pov_character_name = detect_pov(cast, chapter_title) if cast else ""
    if pov_character_name:
        print_info(f"POV character detected: {pov_character_name}")

    # ─── Pass 2: Auto-casting ───
    if "auto_cast_voices" in passes:
        print_header("Pass 2: Auto-Casting")
        if cast is None:
            print_error("Cannot run auto_cast_voices without a cast. Run extract_cast or pass --cast.")
        else:
            print_info(f"Matching {len(cast)} characters against {len(voice_library)} voices...")
            try:
                casting = run_auto_cast_voices(
                    client,
                    cast,
                    voice_library,
                    book_title=book_title,
                    book_author=book_author,
                    model=args.opus_model,
                )
                save_json(casting, run_dir / "casting.json", "casting")
                print_casting(casting)
            except Exception as e:
                print_error(f"Auto-casting failed: {e}")
        check_budget(tracker, args.budget_cap)

    # ─── Pass 3: Pronunciations ───
    if "pronounce_unusual" in passes:
        print_header("Pass 3: Pronunciation Overrides")
        if cast is None:
            print_error("Cannot run pronounce_unusual without a cast.")
        else:
            print_info(f"Analyzing {chapter_words:,} words for pronunciation issues...")
            try:
                prons = run_pronounce_unusual(
                    client,
                    cast,
                    chapter_text,
                    book_title=book_title,
                    book_author=book_author,
                    book_genre=args.genre,
                    model=args.sonnet_model,
                )
                save_json(prons, run_dir / "pronunciations.json", "pronunciations")
                print_pronunciations(prons)
            except Exception as e:
                print_error(f"Pronunciation pass failed: {e}")
        check_budget(tracker, args.budget_cap)

    # ─── Pass 4: Special content ───
    if "detect_special_content" in passes:
        print_header("Pass 4: Special Content Detection")
        try:
            specials = run_detect_special_content(
                client,
                cast or [],
                chapter_text,
                chapter_number=args.chapter or 1,
                chapter_title=chapter_title,
                pov_character_name=pov_character_name,
                model=args.sonnet_model,
            )
            save_json(specials, run_dir / "special_content.json", "special content")
            print_special_content(specials)
        except Exception as e:
            print_error(f"Special content detection failed: {e}")
        check_budget(tracker, args.budget_cap)

    # ─── Pass 5: Attribution ───
    if "attribute_chapter" in passes:
        print_header("Pass 5: Chapter Attribution")
        if cast is None:
            print_error("Cannot run attribute_chapter without a cast.")
        else:
            print_info(f"Attributing segments in '{chapter_title}'...")
            try:
                segments = run_attribute_chapter(
                    client,
                    cast,
                    chapter_text,
                    chapter_number=args.chapter or 1,
                    chapter_title=chapter_title,
                    pov_character_name=pov_character_name,
                    model=args.opus_model,
                )
                save_json(segments, run_dir / "segments.json", "segments")
                print_segments(segments)
            except Exception as e:
                print_error(f"Attribution failed: {e}")
        check_budget(tracker, args.budget_cap)

    # ─── Cost summary ───
    if tracker.records:
        print_header("Cost Summary")
        print_cost_summary(tracker)

    print_header("Complete")
    print_success(f"All outputs saved to: {run_dir}")
    if tracker.records:
        print_info(f"Total cost: ${tracker.total_cost:.4f}")
        print_info(f"Total duration: {tracker.total_duration:.1f}s")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print_error("Interrupted by user")
        sys.exit(130)
