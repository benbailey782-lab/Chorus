"""Book/chapter ingestion from TXT or EPUB files."""
from __future__ import annotations

from pathlib import Path
from typing import Optional

try:
    from ebooklib import epub, ITEM_DOCUMENT
    from bs4 import BeautifulSoup
    EPUB_AVAILABLE = True
except ImportError:
    EPUB_AVAILABLE = False


def load_text_file(path: Path) -> str:
    """Load a plain text file (UTF-8)."""
    return path.read_text(encoding="utf-8")


def extract_epub(path: Path) -> tuple[dict, list[tuple[str, str]]]:
    """Extract chapters from an EPUB file.

    Returns:
        (metadata, chapters)
        - metadata: dict with 'title' and 'author'
        - chapters: list of (title, text) tuples in reading order
    """
    if not EPUB_AVAILABLE:
        raise RuntimeError(
            "EPUB support requires ebooklib and beautifulsoup4. "
            "Install with: pip install ebooklib beautifulsoup4"
        )

    book = epub.read_epub(str(path))

    title_meta = book.get_metadata("DC", "title")
    author_meta = book.get_metadata("DC", "creator")
    metadata = {
        "title": title_meta[0][0] if title_meta else path.stem,
        "author": author_meta[0][0] if author_meta else "Unknown",
    }

    chapters: list[tuple[str, str]] = []
    # Walk in spine order so chapters appear in reading order
    for item_id, _ in book.spine:
        item = book.get_item_with_id(item_id)
        if item is None or item.get_type() != ITEM_DOCUMENT:
            continue

        soup = BeautifulSoup(item.get_body_content(), "html.parser")
        text = soup.get_text(separator="\n", strip=True)
        if not text.strip():
            continue

        heading = soup.find(["h1", "h2", "h3"])
        if heading:
            title = heading.get_text(strip=True)
        else:
            # Try the first non-empty line as title
            first_line = text.strip().split("\n", 1)[0][:80]
            title = first_line if len(first_line) < 80 else f"Chapter {len(chapters) + 1}"

        chapters.append((title, text))

    return metadata, chapters


def extract_chapter(
    book_path: Path,
    chapter_number: Optional[int] = None,
    chapter_title: Optional[str] = None,
) -> tuple[dict, str, str, str]:
    """Load the requested chapter from an EPUB or the full text from a .txt.

    For .txt files, the entire file is treated as both "the chapter" and
    "the full book" (there's no way to slice it without heuristics).

    For EPUB files, if neither chapter_number nor chapter_title is given,
    the first chapter is returned.

    Returns:
        (metadata, chapter_title, chapter_text, full_book_text)
    """
    suffix = book_path.suffix.lower()

    if suffix == ".epub":
        metadata, chapters = extract_epub(book_path)
        if not chapters:
            raise ValueError(f"No readable chapters found in {book_path}")

        full_book_text = "\n\n".join(t for _, t in chapters)

        if chapter_title:
            needle = chapter_title.lower()
            for title, text in chapters:
                if needle in title.lower():
                    return metadata, title, text, full_book_text
            raise ValueError(
                f"No chapter title containing '{chapter_title}'. "
                f"Available titles: {[t for t, _ in chapters[:10]]}"
                + ("..." if len(chapters) > 10 else "")
            )

        if chapter_number is not None:
            idx = chapter_number - 1
            if not (0 <= idx < len(chapters)):
                raise ValueError(
                    f"Chapter {chapter_number} out of range (book has {len(chapters)} chapters)"
                )
            title, text = chapters[idx]
            return metadata, title, text, full_book_text

        # Default: first chapter
        title, text = chapters[0]
        return metadata, title, text, full_book_text

    elif suffix in (".txt", ".md"):
        text = load_text_file(book_path)
        metadata = {"title": book_path.stem.replace("_", " ").title(), "author": "Unknown"}
        return metadata, "Chapter 1", text, text

    else:
        raise ValueError(
            f"Unsupported file format: {suffix}. Supported: .txt, .md, .epub"
        )


def list_chapters(book_path: Path) -> list[tuple[int, str, int]]:
    """Return a list of (number, title, word_count) for each chapter in the book."""
    metadata, chapters = extract_epub(book_path)
    return [
        (i + 1, title, len(text.split()))
        for i, (title, text) in enumerate(chapters)
    ]
