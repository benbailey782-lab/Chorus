"""Voice library loading utilities."""
from __future__ import annotations

import json
from pathlib import Path


def load_voice_library(path: Path) -> list[dict]:
    """Load voice library from a JSON file."""
    return json.loads(path.read_text(encoding="utf-8"))


def get_default_library_path() -> Path:
    """Return path to the bundled sample voice library."""
    return Path(__file__).parent.parent / "sample_voice_library.json"
