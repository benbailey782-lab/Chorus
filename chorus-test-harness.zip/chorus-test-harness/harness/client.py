"""Thin wrapper around the Anthropic SDK with cost tracking and JSON output coaxing.

The key trick: we prefill the assistant message with `[` or `{` to strongly bias
the model toward returning pure JSON. Combined with a system prompt that
emphasizes JSON-only output, this reduces parse failures substantially.
"""
from __future__ import annotations

import os
import time
from dataclasses import dataclass, field
from typing import Optional

from anthropic import Anthropic


# Pricing per million tokens. Update if Anthropic pricing changes.
# Values below are approximate; check https://www.anthropic.com/pricing for current.
MODEL_PRICING: dict[str, dict[str, float]] = {
    "claude-opus-4-7":           {"input": 15.00, "output": 75.00},
    "claude-opus-4-6":           {"input": 15.00, "output": 75.00},
    "claude-sonnet-4-6":         {"input":  3.00, "output": 15.00},
    "claude-haiku-4-5-20251001": {"input":  1.00, "output":  5.00},
}

DEFAULT_PRICING = {"input": 15.00, "output": 75.00}  # conservative fallback


@dataclass
class CallRecord:
    """One recorded API call."""
    pass_name: str
    model: str
    input_tokens: int
    output_tokens: int
    cost_usd: float
    duration_s: float
    success: bool
    error: Optional[str] = None


@dataclass
class CostTracker:
    """Accumulates call records for reporting."""
    records: list[CallRecord] = field(default_factory=list)

    def add(self, record: CallRecord) -> None:
        self.records.append(record)

    @property
    def total_cost(self) -> float:
        return sum(r.cost_usd for r in self.records)

    @property
    def total_input_tokens(self) -> int:
        return sum(r.input_tokens for r in self.records)

    @property
    def total_output_tokens(self) -> int:
        return sum(r.output_tokens for r in self.records)

    @property
    def total_duration(self) -> float:
        return sum(r.duration_s for r in self.records)


class HarnessClient:
    """Wraps Anthropic client with cost tracking and JSON-output coaxing."""

    DEFAULT_SYSTEM = (
        "You are a precision tool that returns ONLY valid JSON. "
        "Never include preamble, explanations, or markdown code fences. "
        "Your response must parse as JSON on the first attempt."
    )

    def __init__(
        self,
        api_key: Optional[str] = None,
        tracker: Optional[CostTracker] = None,
    ):
        key = api_key or os.getenv("ANTHROPIC_API_KEY")
        if not key:
            raise RuntimeError(
                "ANTHROPIC_API_KEY not set. Set it in .env or the environment."
            )
        self.client = Anthropic(api_key=key)
        self.tracker = tracker or CostTracker()

    def call(
        self,
        pass_name: str,
        prompt: str,
        model: str = "claude-opus-4-7",
        max_tokens: int = 16_000,
        expected_format: str = "array",  # "array" or "object"
        temperature: float = 0.0,
        system: Optional[str] = None,
        max_retries: int = 2,
    ) -> tuple[str, CallRecord]:
        """Make a Claude API call. Returns (raw_text, call_record).

        The raw_text includes the prefill character — downstream parsers should
        handle it as a standard JSON start token.
        """
        prefill = "[" if expected_format == "array" else "{"
        system_prompt = system or self.DEFAULT_SYSTEM

        messages = [
            {"role": "user", "content": prompt},
            {"role": "assistant", "content": prefill},
        ]

        attempt = 0
        last_error: Optional[Exception] = None
        while attempt <= max_retries:
            start = time.time()
            try:
                response = self.client.messages.create(
                    model=model,
                    max_tokens=max_tokens,
                    temperature=temperature,
                    system=system_prompt,
                    messages=messages,
                )
                duration = time.time() - start

                raw_text = prefill + response.content[0].text

                input_tokens = response.usage.input_tokens
                output_tokens = response.usage.output_tokens

                pricing = MODEL_PRICING.get(model, DEFAULT_PRICING)
                cost = (
                    input_tokens / 1_000_000 * pricing["input"]
                    + output_tokens / 1_000_000 * pricing["output"]
                )

                record = CallRecord(
                    pass_name=pass_name,
                    model=model,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    cost_usd=cost,
                    duration_s=duration,
                    success=True,
                )
                self.tracker.add(record)
                return raw_text, record

            except Exception as exc:
                last_error = exc
                duration = time.time() - start

                # Retry on transient-looking errors (rate limit, overloaded)
                msg = str(exc).lower()
                transient = (
                    "rate" in msg
                    or "overloaded" in msg
                    or "529" in msg
                    or "timeout" in msg
                )
                if attempt < max_retries and transient:
                    wait = 2 ** attempt * 2  # exponential backoff: 2s, 4s, 8s
                    time.sleep(wait)
                    attempt += 1
                    continue

                # Record the failure and raise
                record = CallRecord(
                    pass_name=pass_name,
                    model=model,
                    input_tokens=0,
                    output_tokens=0,
                    cost_usd=0.0,
                    duration_s=duration,
                    success=False,
                    error=str(exc),
                )
                self.tracker.add(record)
                raise

        # Shouldn't get here, but just in case
        raise RuntimeError(f"Exhausted retries for pass '{pass_name}': {last_error}")
