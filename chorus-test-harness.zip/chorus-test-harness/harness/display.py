"""Terminal display using rich: tables, panels, progress indicators."""
from __future__ import annotations

from typing import Any

from rich.box import ROUNDED
from rich.console import Console
from rich.table import Table


console = Console()


# ─── Headers / messages ──────────────────────────────────────────────────────

def print_header(text: str, style: str = "bold cyan") -> None:
    console.rule(f"[{style}]{text}[/{style}]", style=style)


def print_error(msg: str) -> None:
    console.print(f"[bold red]✗ ERROR:[/bold red] {msg}")


def print_warn(msg: str) -> None:
    console.print(f"[bold yellow]⚠ WARN:[/bold yellow]  {msg}")


def print_success(msg: str) -> None:
    console.print(f"[bold green]✓[/bold green] {msg}")


def print_info(msg: str) -> None:
    console.print(f"[dim]{msg}[/dim]")


# ─── Helpers ─────────────────────────────────────────────────────────────────

def _truncate(s: str, n: int) -> str:
    if not s:
        return ""
    if len(s) <= n:
        return s
    return s[: n - 1] + "…"


def _conf_color(conf: Any) -> str:
    try:
        c = int(conf)
    except (TypeError, ValueError):
        return "dim"
    if c >= 85:
        return "green"
    if c >= 60:
        return "yellow"
    return "red"


# ─── Pass output tables ──────────────────────────────────────────────────────

def print_cast(cast: list[dict]) -> None:
    table = Table(title="Extracted Cast", box=ROUNDED, show_lines=False, expand=True)
    table.add_column("Name", style="cyan", no_wrap=True)
    table.add_column("Gender", style="magenta", width=10)
    table.add_column("Age", style="yellow", width=14)
    table.add_column("Archetype", style="green", width=12)
    table.add_column("Lines", style="blue", width=11)
    table.add_column("Style", style="white")

    for c in cast:
        table.add_row(
            c.get("name", "?"),
            c.get("gender", "?"),
            c.get("age_estimate", "?"),
            c.get("character_archetype", "?"),
            c.get("estimated_line_count", "?"),
            _truncate(c.get("speaking_style", "") or "", 60),
        )
    console.print(table)
    console.print(f"[dim]Total characters: {len(cast)}[/dim]\n")


def print_casting(casting: list[dict]) -> None:
    table = Table(title="Voice Casting", box=ROUNDED, expand=True)
    table.add_column("Character", style="cyan", no_wrap=True)
    table.add_column("Voice", style="green")
    table.add_column("Conf.", justify="right", width=5)
    table.add_column("Flags", style="red", width=22)
    table.add_column("Reasoning", style="dim white")

    for a in casting:
        flags = ", ".join(a.get("flags", []) or [])
        conf = a.get("confidence", 0)
        color = _conf_color(conf)
        voice_name = a.get("voice_display_name") or "[red]UNASSIGNED[/red]"

        table.add_row(
            a.get("character_name", "?"),
            voice_name,
            f"[{color}]{conf}[/{color}]",
            flags,
            _truncate(a.get("reasoning", "") or "", 70),
        )
    console.print(table)

    unassigned = sum(1 for a in casting if not a.get("voice_id"))
    flagged = sum(1 for a in casting if a.get("flags"))
    console.print(
        f"[dim]Total: {len(casting)} | Unassigned: {unassigned} | Flagged: {flagged}[/dim]\n"
    )


def print_pronunciations(prons: list[dict]) -> None:
    if not prons:
        console.print("[dim]No pronunciation overrides generated.[/dim]\n")
        return

    table = Table(title="Pronunciation Overrides", box=ROUNDED, expand=True)
    table.add_column("Word", style="cyan", no_wrap=True)
    table.add_column("Respelling", style="green")
    table.add_column("Category", style="magenta", width=18)
    table.add_column("Conf.", justify="right", width=5)
    table.add_column("Rationale", style="dim white")

    for p in prons:
        conf = p.get("confidence", 0)
        color = _conf_color(conf)
        table.add_row(
            p.get("word", "?"),
            p.get("phonetic_respelling", "?"),
            p.get("category", "?"),
            f"[{color}]{conf}[/{color}]",
            _truncate(p.get("rationale", "") or "", 60),
        )
    console.print(table)
    console.print(f"[dim]Total overrides: {len(prons)}[/dim]\n")


def print_special_content(specials: list[dict]) -> None:
    if not specials:
        console.print("[dim]No special content detected.[/dim]\n")
        return

    table = Table(title="Special Content Spans", box=ROUNDED, expand=True)
    table.add_column("Mode", style="magenta", width=16)
    table.add_column("Text", style="white")
    table.add_column("Speaker", style="cyan")
    table.add_column("Conf.", justify="right", width=5)

    for s in specials:
        conf = s.get("confidence", 0)
        color = _conf_color(conf)
        table.add_row(
            s.get("render_mode", "?"),
            _truncate(s.get("text", "") or "", 70),
            s.get("suggested_speaker") or "-",
            f"[{color}]{conf}[/{color}]",
        )
    console.print(table)
    console.print(f"[dim]Total spans: {len(specials)}[/dim]\n")


def print_segments(segments: list[dict], preview_limit: int = 25) -> None:
    if not segments:
        console.print("[dim]No segments returned.[/dim]\n")
        return

    table = Table(
        title=f"Attributed Segments (preview: {min(preview_limit, len(segments))} of {len(segments)})",
        box=ROUNDED,
        expand=True,
    )
    table.add_column("#", style="dim", justify="right", width=4)
    table.add_column("Speaker", style="cyan", no_wrap=True)
    table.add_column("Mode", style="magenta", width=14)
    table.add_column("Conf.", justify="right", width=5)
    table.add_column("Emotion", style="yellow", width=18)
    table.add_column("Text", style="white")

    for s in segments[:preview_limit]:
        conf = s.get("confidence", 0)
        color = _conf_color(conf)
        emotion = ",".join(s.get("emotion_tags", []) or []) or "-"
        table.add_row(
            str(s.get("order", "?")),
            s.get("character", "?"),
            s.get("render_mode", "?"),
            f"[{color}]{conf}[/{color}]",
            emotion,
            _truncate(s.get("text", "") or "", 70),
        )
    console.print(table)

    # Stats
    low_conf = sum(1 for s in segments if s.get("confidence", 100) < 70)

    mode_counts: dict[str, int] = {}
    for s in segments:
        mode = s.get("render_mode", "unknown")
        mode_counts[mode] = mode_counts.get(mode, 0) + 1

    speaker_counts: dict[str, int] = {}
    for s in segments:
        sp = s.get("character", "unknown")
        speaker_counts[sp] = speaker_counts.get(sp, 0) + 1

    top_speakers = sorted(speaker_counts.items(), key=lambda kv: -kv[1])[:8]

    console.print(f"[dim]Total segments: {len(segments)} | Low-confidence (<70): {low_conf}[/dim]")
    console.print(f"[dim]Render modes: {mode_counts}[/dim]")
    console.print(f"[dim]Top speakers: {top_speakers}[/dim]\n")


# ─── Cost summary ────────────────────────────────────────────────────────────

def print_cost_summary(tracker) -> None:
    table = Table(title="Cost Summary", box=ROUNDED, expand=True)
    table.add_column("Pass", style="cyan")
    table.add_column("Model", style="magenta")
    table.add_column("In Tokens", justify="right")
    table.add_column("Out Tokens", justify="right")
    table.add_column("Cost", justify="right", style="yellow")
    table.add_column("Time (s)", justify="right")
    table.add_column("Status", justify="center", width=8)

    for r in tracker.records:
        status = "[green]OK[/green]" if r.success else "[red]FAIL[/red]"
        table.add_row(
            r.pass_name,
            r.model,
            f"{r.input_tokens:,}",
            f"{r.output_tokens:,}",
            f"${r.cost_usd:.4f}",
            f"{r.duration_s:.1f}",
            status,
        )

    table.add_section()
    table.add_row(
        "[bold]TOTAL[/bold]",
        "",
        f"[bold]{tracker.total_input_tokens:,}[/bold]",
        f"[bold]{tracker.total_output_tokens:,}[/bold]",
        f"[bold]${tracker.total_cost:.4f}[/bold]",
        f"[bold]{tracker.total_duration:.1f}[/bold]",
        "",
    )

    console.print(table)
