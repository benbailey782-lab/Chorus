"""Prompt loading with safe placeholder substitution.

Prompts are stored as Markdown files with {UPPER_SNAKE_CASE} placeholders.
Regular str.format() would break on the literal JSON braces in prompt bodies,
so we use a targeted regex that only matches ALL-CAPS placeholder names.
"""
from __future__ import annotations

import re
from pathlib import Path


# Matches {ALL_CAPS_WITH_UNDERSCORES} — first char must be uppercase letter.
# Carefully designed NOT to match JSON-like `{"key": "value"}` patterns.
_PLACEHOLDER_RE = re.compile(r"\{([A-Z][A-Z0-9_]*)\}")


def load_prompt(path: Path, substitutions: dict[str, str]) -> str:
    """Load a prompt file and substitute {PLACEHOLDER} variables.

    Unknown placeholders are left as-is (no KeyError) — useful for partial
    substitution or debugging.
    """
    text = path.read_text(encoding="utf-8")

    def replace(match: re.Match) -> str:
        name = match.group(1)
        return substitutions.get(name, match.group(0))

    return _PLACEHOLDER_RE.sub(replace, text)


def find_unfilled_placeholders(rendered_prompt: str) -> list[str]:
    """Return any unfilled {PLACEHOLDERS} remaining in the rendered prompt."""
    return [m.group(1) for m in _PLACEHOLDER_RE.finditer(rendered_prompt)]
