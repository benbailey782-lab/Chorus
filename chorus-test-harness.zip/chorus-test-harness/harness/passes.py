"""The five NLP passes. Each runs one prompt, parses the response, returns JSON."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

from .client import HarnessClient
from .prompts import load_prompt, find_unfilled_placeholders


PROMPTS_DIR = Path(__file__).parent.parent / "prompts"


# ─────────────────────────────────────────────────────────────────────────────
# JSON parsing with resilience
# ─────────────────────────────────────────────────────────────────────────────

def parse_json_response(raw: str, expected_format: str = "array"):
    """Parse a Claude JSON response with some resilience to common failures.

    Strategy:
      1. Strip whitespace and markdown code fences
      2. Locate the first array/object start and last matching end
      3. Try json.loads; if fail, attempt a simple trailing-comma repair
    """
    raw = raw.strip()

    # Strip markdown code fences if the model slipped them in
    if raw.startswith("```"):
        # Find the end of the opening fence line
        first_newline = raw.find("\n")
        if first_newline >= 0:
            raw = raw[first_newline + 1:]
        if raw.endswith("```"):
            raw = raw[: raw.rfind("```")].rstrip()

    open_char = "[" if expected_format == "array" else "{"
    close_char = "]" if expected_format == "array" else "}"

    start = raw.find(open_char)
    if start < 0:
        raise ValueError(f"No '{open_char}' found in response. Response starts: {raw[:200]!r}")
    raw = raw[start:]

    end = raw.rfind(close_char)
    if end < 0:
        raise ValueError(f"No '{close_char}' found in response. Response: {raw[:500]!r}")
    raw = raw[: end + 1]

    try:
        return json.loads(raw)
    except json.JSONDecodeError as exc:
        # Minor repair: remove trailing commas before ] or }
        import re
        repaired = re.sub(r",(\s*[\]}])", r"\1", raw)
        try:
            return json.loads(repaired)
        except json.JSONDecodeError:
            raise ValueError(
                f"Failed to parse JSON after repair attempt. "
                f"Original error: {exc.msg} at pos {exc.pos}. "
                f"Raw response (truncated): {raw[:800]!r}"
            ) from exc


def _check_prompt(rendered: str, pass_name: str) -> None:
    """Ensure no placeholders are left unfilled."""
    unfilled = find_unfilled_placeholders(rendered)
    if unfilled:
        raise ValueError(
            f"Unfilled placeholders in {pass_name} prompt: {unfilled}. "
            "Check that all substitution keys were provided."
        )


# ─────────────────────────────────────────────────────────────────────────────
# The passes
# ─────────────────────────────────────────────────────────────────────────────

def run_extract_cast(
    client: HarnessClient,
    book_text: str,
    model: str = "claude-opus-4-7",
) -> list[dict]:
    """Pass 1: Extract cast of speaking characters from the full book."""
    rendered = load_prompt(
        PROMPTS_DIR / "extract_cast.md",
        {"BOOK_TEXT": book_text},
    )
    _check_prompt(rendered, "extract_cast")

    raw, _ = client.call(
        pass_name="extract_cast",
        prompt=rendered,
        model=model,
        expected_format="array",
        max_tokens=16_000,
    )
    return parse_json_response(raw, "array")


def run_auto_cast_voices(
    client: HarnessClient,
    cast: list[dict],
    voice_library: list[dict],
    book_title: str = "",
    book_author: str = "",
    narrative_style: str = "third-person limited with POV shifts",
    model: str = "claude-opus-4-7",
) -> list[dict]:
    """Pass 2: Match voices from the library to each character."""
    # Ensure every cast member has an id (generate deterministic IDs if missing)
    for i, c in enumerate(cast):
        if "id" not in c:
            safe_name = c.get("name", "unknown").lower().replace(" ", "_").replace("'", "")
            c["id"] = f"c_{i:03d}_{safe_name}"

    rendered = load_prompt(
        PROMPTS_DIR / "auto_cast_voices.md",
        {
            "CAST_JSON":         json.dumps(cast, indent=2),
            "VOICE_LIBRARY_JSON": json.dumps(voice_library, indent=2),
            "BOOK_TITLE":        book_title,
            "BOOK_AUTHOR":       book_author,
            "NARRATIVE_STYLE":   narrative_style,
        },
    )
    _check_prompt(rendered, "auto_cast_voices")

    raw, _ = client.call(
        pass_name="auto_cast_voices",
        prompt=rendered,
        model=model,
        expected_format="array",
        max_tokens=16_000,
    )
    return parse_json_response(raw, "array")


def run_pronounce_unusual(
    client: HarnessClient,
    cast: list[dict],
    book_sample: str,
    book_title: str = "",
    book_author: str = "",
    book_genre: str = "fiction",
    model: str = "claude-sonnet-4-6",
) -> list[dict]:
    """Pass 3: Generate pronunciation overrides for unusual names and terms."""
    rendered = load_prompt(
        PROMPTS_DIR / "pronounce_unusual.md",
        {
            "CAST_JSON":         json.dumps(cast, indent=2),
            "BOOK_SAMPLE_TEXT":  book_sample,
            "BOOK_TITLE":        book_title,
            "BOOK_AUTHOR":       book_author,
            "BOOK_GENRE":        book_genre,
        },
    )
    _check_prompt(rendered, "pronounce_unusual")

    raw, _ = client.call(
        pass_name="pronounce_unusual",
        prompt=rendered,
        model=model,
        expected_format="array",
        max_tokens=8_000,
    )
    return parse_json_response(raw, "array")


def run_detect_special_content(
    client: HarnessClient,
    cast: list[dict],
    chapter_text: str,
    chapter_number: int = 1,
    chapter_title: str = "",
    pov_character_name: str = "",
    model: str = "claude-sonnet-4-6",
) -> list[dict]:
    """Pass 4: Detect special content spans in a chapter."""
    rendered = load_prompt(
        PROMPTS_DIR / "detect_special_content.md",
        {
            "CAST_JSON":            json.dumps(cast, indent=2),
            "CHAPTER_TEXT":         chapter_text,
            "CHAPTER_NUMBER":       str(chapter_number),
            "CHAPTER_TITLE":        chapter_title,
            "POV_CHARACTER_NAME":   pov_character_name,
        },
    )
    _check_prompt(rendered, "detect_special_content")

    raw, _ = client.call(
        pass_name="detect_special_content",
        prompt=rendered,
        model=model,
        expected_format="array",
        max_tokens=8_000,
    )
    return parse_json_response(raw, "array")


def run_attribute_chapter(
    client: HarnessClient,
    cast: list[dict],
    chapter_text: str,
    chapter_number: int = 1,
    chapter_title: str = "",
    pov_character_name: str = "",
    model: str = "claude-opus-4-7",
) -> list[dict]:
    """Pass 5: Attribute every segment in a chapter. The big one."""
    rendered = load_prompt(
        PROMPTS_DIR / "attribute_chapter.md",
        {
            "CAST_JSON":            json.dumps(cast, indent=2),
            "CHAPTER_TEXT":         chapter_text,
            "CHAPTER_NUMBER":       str(chapter_number),
            "CHAPTER_TITLE":        chapter_title,
            "POV_CHARACTER_NAME":   pov_character_name,
        },
    )
    _check_prompt(rendered, "attribute_chapter")

    raw, _ = client.call(
        pass_name="attribute_chapter",
        prompt=rendered,
        model=model,
        expected_format="array",
        max_tokens=32_000,  # attribution output is large
    )
    return parse_json_response(raw, "array")


# ─────────────────────────────────────────────────────────────────────────────
# Dry-run support: render prompts to disk without calling the API
# ─────────────────────────────────────────────────────────────────────────────

def dry_render_all(
    out_dir: Path,
    book_text: str,
    chapter_text: str,
    chapter_number: int,
    chapter_title: str,
    pov_character_name: str,
    cast: Optional[list[dict]],
    voice_library: list[dict],
    book_title: str,
    book_author: str,
    book_genre: str,
) -> list[Path]:
    """Render all prompts to files in out_dir without calling the API.

    Useful if you want to paste prompts into Claude Code manually.
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    written = []

    # 1. Extract cast
    r = load_prompt(PROMPTS_DIR / "extract_cast.md", {"BOOK_TEXT": book_text})
    p = out_dir / "01_extract_cast.rendered.md"
    p.write_text(r, encoding="utf-8")
    written.append(p)

    # Placeholder cast if none provided
    cast_for_rendering = cast if cast else [{"id": "c_narrator", "name": "Narrator"}]

    # 2. Auto-cast
    r = load_prompt(
        PROMPTS_DIR / "auto_cast_voices.md",
        {
            "CAST_JSON": json.dumps(cast_for_rendering, indent=2),
            "VOICE_LIBRARY_JSON": json.dumps(voice_library, indent=2),
            "BOOK_TITLE": book_title,
            "BOOK_AUTHOR": book_author,
            "NARRATIVE_STYLE": "third-person limited with POV shifts",
        },
    )
    p = out_dir / "02_auto_cast_voices.rendered.md"
    p.write_text(r, encoding="utf-8")
    written.append(p)

    # 3. Pronunciations
    r = load_prompt(
        PROMPTS_DIR / "pronounce_unusual.md",
        {
            "CAST_JSON": json.dumps(cast_for_rendering, indent=2),
            "BOOK_SAMPLE_TEXT": chapter_text,
            "BOOK_TITLE": book_title,
            "BOOK_AUTHOR": book_author,
            "BOOK_GENRE": book_genre,
        },
    )
    p = out_dir / "03_pronounce_unusual.rendered.md"
    p.write_text(r, encoding="utf-8")
    written.append(p)

    # 4. Special content
    r = load_prompt(
        PROMPTS_DIR / "detect_special_content.md",
        {
            "CAST_JSON": json.dumps(cast_for_rendering, indent=2),
            "CHAPTER_TEXT": chapter_text,
            "CHAPTER_NUMBER": str(chapter_number),
            "CHAPTER_TITLE": chapter_title,
            "POV_CHARACTER_NAME": pov_character_name,
        },
    )
    p = out_dir / "04_detect_special_content.rendered.md"
    p.write_text(r, encoding="utf-8")
    written.append(p)

    # 5. Attribute
    r = load_prompt(
        PROMPTS_DIR / "attribute_chapter.md",
        {
            "CAST_JSON": json.dumps(cast_for_rendering, indent=2),
            "CHAPTER_TEXT": chapter_text,
            "CHAPTER_NUMBER": str(chapter_number),
            "CHAPTER_TITLE": chapter_title,
            "POV_CHARACTER_NAME": pov_character_name,
        },
    )
    p = out_dir / "05_attribute_chapter.rendered.md"
    p.write_text(r, encoding="utf-8")
    written.append(p)

    return written
